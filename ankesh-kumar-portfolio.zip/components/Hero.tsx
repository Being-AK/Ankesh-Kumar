import React from 'react';

export const Hero: React.FC = () => {
  return (
    <section id="about" className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 -z-10 opacity-10 translate-x-1/4 -translate-y-1/4">
        <svg width="600" height="600" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
          <path fill="#059669" d="M45.7,-70.5C58.9,-62.5,69.3,-49.4,75.9,-34.7C82.5,-20,85.3,-3.7,81.6,11.3C77.9,26.3,67.7,40,55.6,50.3C43.5,60.6,29.5,67.5,14.4,70.2C-0.7,72.9,-16.9,71.4,-31.4,64.8C-45.9,58.2,-58.7,46.5,-66.3,32.3C-73.9,18.1,-76.3,1.4,-72.3,-13.3C-68.3,-28,-57.9,-40.7,-46.2,-49.1C-34.5,-57.5,-21.5,-61.6,-7.2,-65.8C7.1,-70,25.2,-74.3,45.7,-70.5Z" transform="translate(100 100)" />
        </svg>
      </div>

      <div className="max-w-6xl mx-auto px-4 flex flex-col-reverse md:flex-row items-center gap-12">
        <div className="flex-1 space-y-6 text-center md:text-left">
          <div className="inline-block px-3 py-1 bg-green-50 text-accent text-sm font-semibold rounded-full border border-green-100">
            Open for Tax & Audit Consultation
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-primary leading-tight">
            Hi, I'm <span className="text-accent">Ankesh Kumar</span>
          </h1>
          <p className="text-xl md:text-2xl text-secondary font-light">
            CA Article @ GPHK & Associates
          </p>
          <p className="text-lg text-slate-600 max-w-lg mx-auto md:mx-0 leading-relaxed">
            Expertise in <strong>GST, TDS, Tax Audits</strong>, and Financial Compliance. 
            I help businesses bridge the gap between complex regulations and clear financial reporting.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start pt-4">
             <a href="#contact" className="px-8 py-3 bg-primary text-white rounded-lg font-semibold hover:bg-slate-800 transition-all shadow-lg hover:translate-y-[-2px]">
              Contact Me
            </a>
            <a href="#projects" className="px-8 py-3 bg-white text-primary border border-slate-200 rounded-lg font-semibold hover:bg-slate-50 transition-all hover:border-slate-300">
              View Work
            </a>
          </div>
        </div>

        <div className="flex-1 flex justify-center md:justify-end relative">
          <div className="relative w-64 h-64 md:w-80 md:h-80">
            <div className="absolute inset-0 bg-accent rounded-2xl rotate-6 opacity-20"></div>
            <div className="absolute inset-0 bg-primary rounded-2xl -rotate-3 opacity-10"></div>
            <img 
              src="https://picsum.photos/seed/ankesh/400/400" 
              alt="Ankesh Kumar" 
              className="relative w-full h-full object-cover rounded-2xl shadow-2xl border-4 border-white"
            />
            {/* Floating Badge */}
            <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-xl border border-slate-100 flex items-center gap-3 animate-bounce-slow">
              <div className="bg-green-100 p-2 rounded-full text-green-600">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              </div>
              <div>
                <p className="text-xs text-secondary font-bold uppercase">Focus</p>
                <p className="text-sm font-bold text-primary">100% Compliance</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};