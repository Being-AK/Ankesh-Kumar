import { GoogleGenAI } from "@google/genai";
import { ABOUT_TEXT, EXPERIENCE, SKILLS, PROJECTS } from "../constants";

// Initialize Gemini Client
// NOTE: In a real production app, you should implement a backend proxy to hide the API key.
// For this portfolio demo, we rely on the environment variable or a safe default.
const apiKey = process.env.API_KEY || ''; 
const ai = new GoogleGenAI({ apiKey });

const SYSTEM_INSTRUCTION = `
You are a professional AI assistant for Ankesh Kumar's portfolio website. 
Your goal is to answer questions about Ankesh's professional background, skills, and experience as a Chartered Accountant (CA) Articled Assistant.

Here is the context about Ankesh:
About: ${ABOUT_TEXT}
Experience: ${JSON.stringify(EXPERIENCE)}
Skills: ${JSON.stringify(SKILLS)}
Projects: ${JSON.stringify(PROJECTS)}

Rules:
1. Be polite, professional, and concise.
2. Only answer based on the provided context. If the answer is not in the context, say "I don't have that specific information, but you can contact Ankesh directly."
3. Highlight his expertise in GST, TDS, and Audits.
4. Keep answers under 3 sentences unless asked for a detailed list.
`;

export const askGemini = async (userQuestion: string): Promise<string> => {
  if (!apiKey) {
    return "I'm currently offline (API Key missing). Please contact Ankesh via email!";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: userQuestion,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      }
    });

    return response.text || "I couldn't generate a response at this time.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, I encountered an error while thinking. Please try again later.";
  }
};